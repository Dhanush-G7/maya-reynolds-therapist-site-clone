"use client";
import { useState } from "react";

const links = [
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Office", href: "#office" },
  { label: "FAQs", href: "#faqs" },
  { label: "Contact", href: "#contact" },
];
const btn = "border border-maya-sea px-5 py-3 text-[.68rem] uppercase tracking-[.15em] text-maya-sea transition hover:bg-maya-sea hover:text-maya-paper";

export default function MayaNavbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-maya-line bg-maya-paper/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between px-[6vw] py-5">
        <a href="#top">
          <span className="block font-display text-[1.6rem] leading-none text-maya-sea">Dr. Maya Reynolds</span>
          <span className="mt-1 block text-[.61rem] uppercase tracking-[.23em] text-maya-muted">PsyD · Santa Monica, CA</span>
        </a>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-[.72rem] uppercase tracking-[.13em] text-maya-muted hover:text-maya-sea">{l.label}</a>
          ))}
          <a href="#contact" className={btn}>Book a Free Consult</a>
        </nav>
        <button aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)} className="grid h-11 w-11 place-items-center border border-maya-sea text-maya-sea md:hidden">{open ? "×" : "☰"}</button>
      </div>
      {open && (
        <nav className="border-t border-maya-line bg-maya-paper px-[6vw] py-5 md:hidden">
          <div className="flex flex-col">
            {links.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="border-b border-maya-line py-4 text-xs uppercase tracking-[.14em]">{l.label}</a>
            ))}
            <a href="#contact" onClick={() => setOpen(false)} className={`${btn} mt-5 text-center`}>Book a Free Consult</a>
          </div>
        </nav>
      )}
    </header>
  );
}
