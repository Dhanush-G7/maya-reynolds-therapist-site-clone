// Dr. Maya Reynolds homepage. All photos are bundled locally in /public/images/maya.
const IMG = {
  portrait: "/images/maya/portrait.jpg",
  office1: "/images/maya/office1.jpeg",
  office2: "/images/maya/office2.jpeg",
};
const ADDRESS = "123th Street 45 W, Santa Monica, CA 90401";

const eyebrow = "text-[.72rem] uppercase tracking-[.18em]";
const display = "font-display font-light leading-[1.02] text-maya-sea";
const btn = "inline-flex w-fit border border-maya-sea px-7 py-4 text-xs uppercase tracking-[.16em] text-maya-sea transition hover:bg-maya-sea hover:text-maya-paper";
const frame = "image-frame overflow-hidden";
const Photo = ({ src, alt, className = "" }: { src: string; alt: string; className?: string }) => (
  <div className={`${frame} ${className}`}><img src={src} alt={alt} className="h-full w-full object-cover" /></div>
);

export function MayaHero() {
  return (
    <section id="top" className="grid min-h-[calc(100vh-81px)] md:grid-cols-[1.08fr_.92fr]">
      <div className="flex flex-col justify-center px-[6vw] py-20">
        <p className={`${eyebrow} mb-7 text-maya-muted`}>In-person in Santa Monica · Secure telehealth across California</p>
        <h1 className={`${display} max-w-[760px] text-[clamp(2.9rem,5.6vw,5.8rem)]`}>Anxiety &amp; Trauma Therapist in <em className="text-maya-amber">Santa Monica, CA</em></h1>
        <p className="mt-8 max-w-xl text-base font-light leading-8 text-maya-muted md:text-lg">You can look like you’re holding it all together and still feel exhausted inside. With a warm, paced approach, I help adults in Santa Monica and across California calm anxiety, heal from past experiences, and feel safe in their own minds and bodies again.</p>
        <a href="#contact" className={`${btn} mt-10`}>Book a Free 15-Minute Consult</a>
      </div>
      <Photo src={IMG.portrait} alt="Portrait of Dr. Maya Reynolds, PsyD" className="min-h-[520px] md:min-h-0" />
    </section>
  );
}

export function MayaIntro() {
  return (
    <section className="section-pad bg-maya-paper">
      <div className="mx-auto grid max-w-[1200px] gap-14 lg:grid-cols-[1.2fr_.72fr] lg:items-center">
        <div>
          <h2 className={`${display} max-w-4xl text-[clamp(2.5rem,4.6vw,5rem)]`}>Overwhelmed by anxiety, stress, or what you’ve been through?</h2>
          <div className="mt-14 grid gap-10 md:grid-cols-2">
            <div>
              <p className={`${eyebrow} mb-5 text-maya-ink`}>You don’t have to keep pushing through it alone.</p>
              <p className="font-light leading-8 text-maya-muted">Many of the people I work with are high-achieving, thoughtful, and self-aware, but internally feel exhausted, stuck in overthinking, or emotionally on edge. Therapy here is warm, collaborative, and grounded.</p>
            </div>
            <p className="font-light leading-8 text-maya-muted">I integrate evidence-based methods that help you understand both the emotional and physiological sides of what you’re experiencing, so you can feel steadier in daily life, not just during sessions.</p>
          </div>
        </div>
        <Photo src={IMG.office2} alt="A calm corner of the Santa Monica therapy office" className="h-[520px] lg:h-[660px]" />
      </div>
    </section>
  );
}

const who = [
  { title: "Adults with anxiety & panic", text: "Constant worry, racing thoughts, or panic wearing you down? Together we’ll calm your body and quiet the overthinking with CBT and mindfulness-based tools." },
  { title: "Adults healing from past experiences", text: "For adults carrying the effects of trauma, we move at your pace, with safety and stabilization first, so you feel more regulated in everyday life." },
  { title: "Entrepreneurs, creatives & professionals", text: "If burnout, perfectionism, or high internal pressure has you disconnected, you can slow down and reconnect without losing your drive." },
];
export function MayaWho() {
  return (
    <section className="section-pad border-t border-maya-line bg-maya-mist">
      <div className="mx-auto max-w-[1200px]">
        <p className={`${eyebrow} text-maya-muted`}>Who I help</p>
        <div className="mt-14 grid gap-12 md:grid-cols-3 md:gap-8">
          {who.map((x, i) => (
            <article key={x.title} className="border-t border-maya-sea/30 pt-7">
              <span className="text-xs text-maya-muted">0{i + 1}</span>
              <h3 className="mt-4 font-display text-3xl font-light text-maya-sea">{x.title}</h3>
              <p className="mt-4 font-light leading-7 text-maya-muted">{x.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

const focus = ["Anxiety", "Panic", "Trauma", "Burnout", "Perfectionism", "Stress & overthinking", "High internal pressure"];
export function MayaExpertise() {
  return (
    <section className="section-pad bg-maya-sea text-maya-paper">
      <div className="mx-auto max-w-[1200px]">
        <p className={`${eyebrow} opacity-80`}>Areas I focus on</p>
        <h2 className="mt-7 max-w-5xl font-display text-[clamp(2.6rem,5.4vw,5.6rem)] font-light leading-[.98]">A safe, steady place to understand what your mind and body are telling you. <em className="text-maya-glass">We go at your speed.</em></h2>
        <div className="mt-16 flex flex-wrap gap-x-7 gap-y-4 border-t border-maya-paper/30 pt-8">
          {focus.map((x) => <span key={x} className="font-display text-2xl italic md:text-3xl">{x}</span>)}
          <span className="font-display text-2xl italic md:text-3xl">…and more.</span>
        </div>
      </div>
    </section>
  );
}

export function MayaAbout() {
  return (
    <section id="about" className="section-pad bg-maya-paper">
      <div className="mx-auto max-w-[1200px]">
        <p className={`${eyebrow} text-maya-muted`}>About Dr. Maya Reynolds</p>
        <h2 className={`${display} mt-5 max-w-4xl text-[clamp(2.8rem,5.2vw,5.4rem)]`}>Warm, collaborative, and grounded.</h2>
        <div className="mt-16 grid gap-12 lg:grid-cols-[.85fr_1.15fr] lg:items-start">
          <Photo src={IMG.office1} alt="Sunlit therapy room with a grey sofa and tall windows" className="aspect-[4/5]" />
          <div className="max-w-2xl font-light text-maya-muted">
            <p className="leading-8">I’m a licensed clinical psychologist based in Santa Monica, California, working with adults.</p>
            <p className="mt-7 leading-8">My work often focuses on anxiety, panic, trauma, and burnout. I take a warm, collaborative, and grounded approach, integrating evidence-based methods that help you understand both the emotional and physiological sides of what you’re experiencing.</p>
            <p className="mt-7 leading-8">Trauma work is an important part of my practice, paced carefully with an emphasis on safety, stabilization, and helping you feel more regulated in daily life. I also support entrepreneurs, creatives, and professionals dealing with burnout, perfectionism, and high internal pressure.</p>
            <p className="mt-7 font-normal leading-8 text-maya-ink">Methods I use: CBT · EMDR · Mindfulness-based practices · Body-oriented techniques</p>
            <a href="#contact" className="soft-link mt-9 inline-block text-xs uppercase tracking-[.16em] text-maya-sea">Book a free consult</a>
          </div>
        </div>
      </div>
    </section>
  );
}

const services = [
  { title: "Anxiety Therapy in Santa Monica", text: "If constant worry, racing thoughts, or panic are wearing you down, anxiety therapy in Santa Monica can help. Together we’ll use CBT and mindfulness-based tools to calm your body and quiet the overthinking." },
  { title: "Trauma Therapy & EMDR in Santa Monica", text: "For adults carrying the effects of past experiences, trauma therapy with EMDR offers a carefully paced path toward safety and steadiness. We focus on stabilization first so you feel more regulated in daily life, not just in session." },
  { title: "Burnout & Perfectionism Counseling near Santa Monica", text: "If you’re a high achiever who feels disconnected after years of pushing through stress, burnout counseling can help you slow down and reconnect. You’ll build more sustainable ways of working and living, without losing your drive." },
];
export function MayaServices() {
  return (
    <section id="services" className="section-pad bg-maya-glass">
      <div className="mx-auto max-w-[1200px]">
        <p className={`${eyebrow} text-maya-muted`}>How I can help you</p>
        <h2 className={`${display} mt-5 text-[clamp(2.8rem,4.8vw,5.2rem)]`}>Support that moves at your pace.</h2>
        <div className="mt-16 grid gap-x-10 gap-y-14 md:grid-cols-3">
          {services.map((c, i) => (
            <article key={c.title} className="border-t border-maya-sea/30 pt-7">
              <div className="flex items-start justify-between gap-4">
                <h3 className="font-display text-3xl font-light text-maya-sea">{c.title}</h3>
                <span className="text-xs text-maya-muted">0{i + 1}</span>
              </div>
              <p className="mt-5 font-light leading-7 text-maya-muted">{c.text}</p>
              <a href="#contact" className="soft-link mt-6 inline-block text-xs uppercase tracking-[.16em] text-maya-sea">Learn more</a>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

// NEW section (Part 3): does not exist in the original template.
export function MayaOffice() {
  return (
    <section id="office" className="section-pad bg-maya-paper">
      <div className="mx-auto max-w-[1200px]">
        <p className={`${eyebrow} text-maya-muted`}>Our office</p>
        <h2 className={`${display} mt-5 max-w-4xl text-[clamp(2.8rem,5vw,5.2rem)]`}>A calm space for healing, in Santa Monica</h2>
        <div className="mt-14 grid gap-10 lg:grid-cols-[.9fr_1.1fr] lg:items-start">
          <div className="max-w-xl font-light text-maya-muted">
            <p className="leading-8">My office is a quiet, private space designed to feel calm and grounding, with natural light and a comfortable, uncluttered environment. I offer in-person therapy from my Santa Monica office and secure telehealth sessions for clients located in California.</p>
            <address className="mt-7 font-normal not-italic text-maya-sea">{ADDRESS}</address>
            <p className="mt-2 text-sm">In-person or telehealth · Private, comfortable, and unhurried</p>
            <a href="https://www.google.com/maps/search/?api=1&query=123+Street+45+W,+Santa+Monica,+CA+90401" className={`${btn} mt-8`}>Get directions</a>
          </div>
          <div className="grid gap-6 sm:grid-cols-2">
            <Photo src={IMG.office1} alt="Sunlit therapy office with a grey sofa and glass coffee table" className="aspect-[4/5]" />
            <Photo src={IMG.office2} alt="Another calm, uncluttered view of the therapy office" className="aspect-[4/5] sm:mt-12" />
          </div>
        </div>
      </div>
    </section>
  );
}

const faqs = [
  ["Do you offer in-person and online therapy?", "Yes. I see clients in person at my Santa Monica office and offer secure telehealth sessions for clients located in California."],
  ["Who do you work with?", "Adults who feel overwhelmed by anxiety, stress, or the lingering effects of past experiences, including entrepreneurs, creatives, and professionals facing burnout and perfectionism."],
  ["How do you approach trauma therapy?", "Carefully and at your pace, with an emphasis on safety and stabilization, so you feel more regulated in daily life and not only during sessions."],
  ["What methods do you use?", "CBT, EMDR, mindfulness-based practices, and body-oriented techniques."],
  ["Where is your office?", ADDRESS + "."],
];
export function MayaFaq() {
  return (
    <section id="faqs" className="section-pad border-t border-maya-line bg-maya-mist">
      <div className="mx-auto max-w-[900px]">
        <p className={`${eyebrow} text-maya-muted`}>FAQs</p>
        <h2 className={`${display} mt-5 text-[clamp(2.6rem,4.4vw,4.6rem)]`}>Frequently asked questions</h2>
        <div className="mt-12">
          {faqs.map(([q, a]) => (
            <details key={q} className="border-b border-maya-line py-5">
              <summary className="cursor-pointer font-display text-2xl text-maya-sea">{q}</summary>
              <p className="mt-3 font-light leading-8 text-maya-muted">{a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

const field = "border border-maya-sea/40 bg-maya-paper px-4 py-3 font-light";
export function MayaContact() {
  return (
    <section id="contact" className="section-pad bg-maya-paper">
      <div className="mx-auto max-w-[1200px]">
        <p className={`${eyebrow} text-maya-muted`}>Free 15-minute consult</p>
        <h2 className={`${display} mt-5 max-w-5xl text-[clamp(2.8rem,5.4vw,5.6rem)]`}>Let’s talk about what would help <em className="text-maya-amber">you.</em></h2>
        <div className="mt-14 grid gap-10 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
          <div className="max-w-2xl">
            <p className="font-light leading-8 text-maya-muted">Share a few details and I’ll follow up to set up a time. Please don’t include sensitive details in this form.</p>
            {/* TODO: point action at your form service (Formspree, Netlify Forms...) */}
            <form action="#" className="mt-8 grid gap-3">
              <input required placeholder="Name" className={field} />
              <input required type="email" placeholder="Email" className={field} />
              <select className={field}><option>In-person</option><option>Telehealth</option></select>
              <textarea rows={3} placeholder="Short message" className={field} />
              <button className={`${btn} mt-2`}>Schedule my free consult</button>
            </form>
          </div>
          <Photo src={IMG.office2} alt="Quiet corner of the Santa Monica office" className="aspect-[4/3]" />
        </div>
      </div>
    </section>
  );
}

export function MayaFooter() {
  return (
    <footer className="bg-maya-sea px-[6vw] py-16 text-maya-paper">
      <div className="mx-auto max-w-[1200px]">
        <div className="grid gap-12 border-b border-maya-paper/20 pb-14 md:grid-cols-3">
          <div>
            <h2 className="font-display text-3xl font-light">Dr. Maya Reynolds, PsyD</h2>
            <p className="mt-3 max-w-xs text-sm font-light leading-7 text-maya-paper/80">Therapy for adults in Santa Monica and across California, in person or by secure telehealth.</p>
          </div>
          <div>
            <p className={`${eyebrow} text-maya-paper/60`}>Navigate</p>
            <div className="mt-5 flex flex-col gap-3 text-sm text-maya-paper/85">
              <a href="#top">Home</a><a href="#services">Services</a><a href="#about">About</a><a href="#office">Office</a><a href="#faqs">FAQs</a><a href="#contact">Contact</a>
            </div>
          </div>
          <div>
            <p className={`${eyebrow} text-maya-paper/60`}>Contact</p>
            <address className="mt-5 text-sm not-italic leading-7 text-maya-paper/85">123th Street 45 W<br />Santa Monica, CA 90401</address>
          </div>
        </div>
        <div className="flex flex-col gap-4 pt-7 text-xs text-maya-paper/60 md:flex-row md:items-center md:justify-between">
          <p>If you are in crisis: call or text 988 (U.S.) or call 911.</p>
          <p>© 2026 Dr. Maya Reynolds, PsyD.</p>
        </div>
      </div>
    </footer>
  );
}
