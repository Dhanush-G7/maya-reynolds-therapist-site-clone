import type { Metadata } from "next";
import MayaNavbar from "@/components/MayaNavbar";
import { MayaHero, MayaIntro, MayaWho, MayaExpertise, MayaAbout, MayaServices, MayaOffice, MayaFaq, MayaContact, MayaFooter } from "@/components/MayaSections";

export const metadata: Metadata = {
  title: "Anxiety & Trauma Therapist in Santa Monica, CA | Dr. Maya Reynolds, PsyD",
  description: "Anxiety, trauma and burnout therapy for adults in Santa Monica, CA. In-person sessions and secure California telehealth with EMDR and CBT. Book a free consult.",
};

export default function Home() {
  return (
    <main className="site-shell bg-maya-paper font-body text-maya-ink">
      <MayaNavbar />
      <MayaHero /><MayaIntro /><MayaWho /><MayaExpertise /><MayaAbout /><MayaServices /><MayaOffice /><MayaFaq /><MayaContact /><MayaFooter />
    </main>
  );
}
